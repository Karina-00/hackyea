from django.apps import AppConfig


class BazaConfig(AppConfig):
    name = 'baza'
