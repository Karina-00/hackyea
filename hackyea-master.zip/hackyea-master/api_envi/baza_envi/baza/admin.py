from django.contrib import admin
from .models import Artykul

admin.site.register(Artykul)