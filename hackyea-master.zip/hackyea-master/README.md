Zainstalowanie venv,
0. Zainstalujecie z neta pythona
1. Otwórz terminal
2. Wejdz w terminalu do folderu z bazą danych do folderu Scripts (cd (nazwa folderu))
3. Wpisz activate
3,5. Wpisz pip install django
3,75. Wpisz pip install djangorestframework
3,8. Wpisz pip install django-cors-headers
3,9. Zainstaluj wsparcie do pythona na visual studio code
4. Gotowe!